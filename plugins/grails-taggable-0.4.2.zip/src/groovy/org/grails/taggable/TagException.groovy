package org.grails.taggable

class TagException extends RuntimeException {

	TagException(String msg) {
		super(msg)
	}

}